## Note 
Tout ce qui touche au descripteur n'est pas implémenté 
La possiblité de chercher des images similaires n'est pas implémenté

## Important
Pour lancer correctement le serveur il faut faire attention de bien avoir le nom d'une database du cremi ainsi que son mot de passe défini en variable d'environnement
au cas où ça ne soit pas le cas pour le faire il faut faire les commande suivante:
export DATABASE_NAME={id de la personne}
export DATABASE_PASSWORD={mot de passe de la database de la personne}

# Systeme d'exploitation testé 
- Debian
- Manjaro Linux

# Navigateur testé
- brave 1.63.174
- Firefox 124.0