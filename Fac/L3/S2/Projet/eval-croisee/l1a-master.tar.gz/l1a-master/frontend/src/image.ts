export type ImageType = {
    name: string
    id: number
    type: string
    size: string
}