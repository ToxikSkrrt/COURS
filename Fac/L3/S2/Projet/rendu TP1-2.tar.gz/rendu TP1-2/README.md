# Rendu TP1-2  ||  Thomas-Alexandre MOREAU

## Partie(s) manquante(s)

- Implémentation de POST dans le frontend

## Difficulté(s) rencontrée(s)

- Implémentation de 'addImage()' et 'getImagesList()' dans 'ImageController.java'
- Difficultés à comprendre le fonctionnement des tests pour le backend
  - Difficultés à faire les deux derniers tests
- Manipulation du frontend en général, particulièrement Vue
  - Savoir quoi faire des données récupérées du backend, etc
  - Le fait de devoir en quelque sorte "oublier" mes connaissances de base du HTML car globalement remplacées par ce qu'apporte Vue
- Pour l'implémentation de POST sur le frontend, en ayant suivi le tutoriel cela n'a pas fonctionné, et après quelques manipulations pour enlever les erreurs affichées, il y avait des warnings pour préciser que des éléments du code n'était plus suivis (outdated)
