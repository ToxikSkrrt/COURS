#include "game_tools.h"

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "game.h"
#include "game_ext.h"

game game_load(char *filename) {
    return NULL;
}

void game_save(cgame g, char *filename) {
}