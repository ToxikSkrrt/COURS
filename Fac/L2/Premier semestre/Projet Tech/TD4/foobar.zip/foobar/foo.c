// foo.c

int foo(int x)
{
    return ++x;
}
