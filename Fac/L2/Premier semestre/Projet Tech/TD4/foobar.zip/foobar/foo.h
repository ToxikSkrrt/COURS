// foo.h

#ifndef __FOO_H__
#define __FOO_H__

#define VALUE 100
int foo(int x);

#endif
