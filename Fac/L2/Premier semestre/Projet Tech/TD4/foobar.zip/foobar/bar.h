// bar.h

#ifndef __BAR_H__
#define __BAR_H__

double bar(double x);

#endif
