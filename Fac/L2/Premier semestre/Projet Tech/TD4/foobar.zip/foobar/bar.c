// bar.c

#include "bar.h"

double bar(double x)
{
    return x * x;
}
